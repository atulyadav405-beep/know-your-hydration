/* ═══════════════════════════════════════════════════════════
   Know Your Hydration — Expandable Chat Widget
   Injects itself; call initChat() after DOM load
═══════════════════════════════════════════════════════════ */

const CHAT_SUGGESTIONS = [
  'Why do I get cramps during runs?',
  'How much sodium do I need for a 90-min session?',
  'Whats the difference between Na K and Mg?',
  'Is coconut water enough for hydration?',
  'What should I drink in Indian summer heat?',
  'How does taurine help in heat?',
];

const CHAT_ANSWERS = {
  'cramp': {
    text: 'Cramps are usually a sodium + potassium problem, not a fitness problem. As you sweat, you lose Na and K — the two electrolytes that power the electrical signal controlling muscle contraction. When levels drop, the muscle fires and can\'t stop. Magnesium makes it worse: without Mg, the Na/K pump can\'t reset the signal. Fix: replace 400–800mg Na per hour and include Mg.',
    source: 'Baker 2017 · Apell 2017',
    url: 'https://pubmed.ncbi.nlm.nih.gov/28332116/'
  },
  'sodium': {
    text: 'For a 90-min moderate-intensity session: aim for 400–600mg Na per hour. Heavy sweaters or those training in Indian heat should target 700–900mg/hr. Start your electrolytes in the first 20 minutes — don\'t wait for thirst. Pre-load 400mg about 60–90 minutes before.',
    source: 'Baker 2017 · Vrijens & Rehrer 1999',
    url: 'https://pubmed.ncbi.nlm.nih.gov/26702122/'
  },
  'na k mg': {
    text: 'Na (sodium) is the primary extracellular ion — drives plasma volume and fluid retention. K (potassium) is the intracellular partner — the Na/K pump moves 3 Na out per K cycle. Mg (magnesium) is the obligate cofactor — without it the pump literally cannot run regardless of how much Na or K you have. Most people get Na and K right but ignore Mg.',
    source: 'Apell 2017 · McKenna 2021',
    url: 'https://pubmed.ncbi.nlm.nih.gov/28877436/'
  },
  'coconut': {
    text: 'Coconut water is high in potassium (~700mg/500ml) and near-isotonic, which makes it good for light recovery. But it\'s relatively low in sodium (~190mg/500ml) and contains ~25g sugar. For heavy exercise or heat, it won\'t replace sodium fast enough. Better as a recovery drink than a during-exercise drink. Avoid if you have CKD — the K level is dangerous.',
    source: 'PMC3293068 · PMC11789751',
    url: 'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3293068/'
  },
  'heat': {
    text: 'In Indian summer heat (WBGT 28–35°C), your sweat rate can exceed 1.5–2L per hour. Each litre of sweat contains ~920mg sodium. That means a 2-hour outdoor session can deplete 2,000–3,700mg Na — far more than most electrolyte drinks replace. Target 700–1000mg Na per hour, start before you feel thirsty, and consider taurine which improves cell stability under heat stress.',
    source: 'PMC4730480 · PMC12943169 · Baker 2017',
    url: 'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4730480/'
  },
  'taurine': {
    text: 'Taurine is an organic osmolyte — it helps cells maintain their volume and function under heat and osmotic stress. Research shows it can increase sweat efficiency by 8–15% under heat (Peel 2024). Importantly, it does NOT directly improve cognition — that claim is overclaimed. Its cognitive benefit is indirect: by preventing dehydration, it prevents the 10% cognitive decline that comes with it.',
    source: 'PMC12943169 · 2025 meta-analysis (n=402)',
    url: 'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC12943169/'
  },
};

function matchAnswer(q) {
  const lq = q.toLowerCase();
  if (lq.includes('cramp')) return CHAT_ANSWERS['cramp'];
  if (lq.includes('sodium') || lq.includes('na ') || lq.includes('90') || lq.includes('how much')) return CHAT_ANSWERS['sodium'];
  if (lq.includes('coconut')) return CHAT_ANSWERS['coconut'];
  if (lq.includes('heat') || lq.includes('summer') || lq.includes('india') || lq.includes('wbgt')) return CHAT_ANSWERS['heat'];
  if (lq.includes('taurine')) return CHAT_ANSWERS['taurine'];
  if (lq.includes('mg') || lq.includes('magnesium') || lq.includes('potassium') || lq.includes('na k') || lq.includes('difference')) return CHAT_ANSWERS['na k mg'];
  return null;
}

function initChat() {
  // Inject HTML
  const widget = document.createElement('div');
  widget.className = 'chat-widget';
  widget.innerHTML = `
    <div class="chat-panel" id="chatPanel">
      <div class="chat-panel-head">
        <div class="chat-panel-avatar">💧</div>
        <div>
          <div class="chat-panel-title">Ask the Database</div>
          <div class="chat-panel-sub">Evidence-based answers · Sources included</div>
        </div>
        <button class="chat-panel-close" onclick="closeChat()" aria-label="Close">✕</button>
      </div>

      <div class="chat-messages" id="chatMessages">
        <div class="chat-msg chat-msg-bot">
          Hey! Ask me anything about hydration, electrolytes, or athlete performance. Every answer comes with a source you can verify. 👇
        </div>
      </div>

      <div class="chat-suggestions" id="chatSuggestions">
        ${CHAT_SUGGESTIONS.slice(0,3).map(s =>
          `<button class="chat-suggestion" onclick="sendSuggestion('${s.replace(/'/g, "\\'")}')">${s}</button>`
        ).join('')}
      </div>

      <div class="chat-input-row">
        <input class="chat-panel-input" type="text" id="chatPanelInput"
          placeholder="Ask about cramps, sodium, recovery…"
          onkeypress="if(event.key==='Enter')sendChatMsg()"/>
        <button class="chat-panel-send" onclick="sendChatMsg()" aria-label="Send">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
            <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
          </svg>
        </button>
      </div>
      <div class="chat-panel-footer">Powered by 60+ peer-reviewed sources · <a href="library.html" style="color:var(--teal)">Full library →</a></div>
    </div>

    <button class="chat-trigger" id="chatTrigger" onclick="toggleChat()" aria-label="Open chat">
      <div class="chat-badge" id="chatBadge">1</div>
      <svg class="icon-open" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
      </svg>
      <svg class="icon-close" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
      </svg>
    </button>
  `;
  document.body.appendChild(widget);
}

let chatOpen = false;

function toggleChat() {
  chatOpen ? closeChat() : openChat();
}

function openChat() {
  chatOpen = true;
  document.getElementById('chatPanel').classList.add('open');
  document.getElementById('chatTrigger').classList.add('open');
  document.getElementById('chatBadge').classList.add('hidden');
  setTimeout(() => document.getElementById('chatPanelInput').focus(), 250);
}

function closeChat() {
  chatOpen = false;
  document.getElementById('chatPanel').classList.remove('open');
  document.getElementById('chatTrigger').classList.remove('open');
}

function sendSuggestion(text) {
  document.getElementById('chatPanelInput').value = text;
  document.getElementById('chatSuggestions').style.display = 'none';
  sendChatMsg();
}

function sendChatMsg() {
  const input = document.getElementById('chatPanelInput');
  const q = (input.value || '').trim();
  if (!q) return;
  input.value = '';

  const messages = document.getElementById('chatMessages');
  document.getElementById('chatSuggestions').style.display = 'none';

  // User bubble
  const userMsg = document.createElement('div');
  userMsg.className = 'chat-msg chat-msg-user';
  userMsg.textContent = q;
  messages.appendChild(userMsg);

  // Typing indicator
  const typing = document.createElement('div');
  typing.className = 'chat-msg-typing';
  typing.innerHTML = '<span></span><span></span><span></span>';
  messages.appendChild(typing);
  messages.scrollTop = messages.scrollHeight;

  // Answer after short delay
  setTimeout(() => {
    messages.removeChild(typing);
    const answer = matchAnswer(q);
    const botMsg = document.createElement('div');
    botMsg.className = 'chat-msg chat-msg-bot';

    const disclaimer = `
      <div style="margin-top:12px;padding:10px 12px;background:#FFF7ED;border:1px solid #FED7AA;border-left:3px solid #EA580C;border-radius:8px;font-size:11px;color:#7C3400;line-height:1.55;">
        ⚕️ <strong>Clinical note:</strong> This answer is derived from peer-reviewed research
        ${answer ? `(<em>${answer.source}</em>)` : ''}.
        Individual needs vary. Always consult a registered dietitian or sports medicine professional
        for personalised guidance.
      </div>`;

    if (answer) {
      botMsg.innerHTML = `${answer.text}<br/><br/>
        <span style="font-size:11px;color:var(--ink-4)">Source: ${answer.source}</span>
        ${answer.url ? ` · <a href="${answer.url}" target="_blank" rel="noopener" style="font-size:11px;color:var(--teal);font-weight:600;">Read paper ↗</a>` : ''}
        ${disclaimer}`;
    } else {
      botMsg.innerHTML = `Great question — for a full evidence-based answer, ask it in the complete database. It can compare products, explain mechanisms, and cite specific papers.<br/><br/>
        <a href="https://atulyadav405-beep.github.io/hydration-reference/?q=${encodeURIComponent(q)}" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:6px;background:var(--teal);color:#fff;font-size:12px;font-weight:600;padding:7px 14px;border-radius:var(--r-md);text-decoration:none;margin-top:4px">Open full database ↗</a>
        ${disclaimer}`;
    }

    messages.appendChild(botMsg);
    messages.scrollTop = messages.scrollHeight;
  }, 900 + Math.random() * 400);
}
